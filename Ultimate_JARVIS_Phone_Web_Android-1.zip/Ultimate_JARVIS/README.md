# ULTIMATE JARVIS — Browser + Python Companion

A redesigned reactor-command project for a voice-enabled AI assistant with:
- Extreme futuristic animated reactor, radar sweep, and honest live browser telemetry.
- Browser UI that works in Chrome on Android and Windows.
- Optional speech recognition and spoken responses (browser support varies).
- Real AI responses through a configurable OpenAI-compatible API (Groq-compatible defaults).
- Web search through the optional Tavily Search API.
- A localhost-only Python companion for narrowly allowlisted Windows app launching and system-volume controls.
- Explicit confirmation before device actions.

## What works where?

| Feature | Android Chrome | Windows Chrome + Python companion |
|---|---|---|
| Browser UI/chat | Yes | Yes |
| Voice input/output | If browser supports it and permission is granted | If browser supports it and permission is granted |
| Real AI | Yes, while the companion/server is running and API key is configured | Yes |
| Web search | Yes, with Tavily key configured | Yes |
| Open websites/search results | Yes | Yes |
| Open allowlisted desktop apps | No (browser sandbox) | Yes, allowlist only |
| System volume/mute | No (browser sandbox) | Yes, Windows companion only |
| Arbitrary shell commands / unrestricted control | Never provided | Never provided |

**Important:** Android browser pages cannot get unrestricted app-launch or system-volume permissions. This project does not bypass Android security or install a hidden service. The Windows companion is a local Python process and only exposes specific allowlisted actions.

## Quick start — Windows

1. Install Python 3.11+ from https://www.python.org/downloads/ (enable “Add Python to PATH”).
2. Extract this ZIP into a normal folder.
3. Double-click `setup_windows.bat`. It creates a virtual environment and installs dependencies.
4. Copy `.env.example` to `.env`.
5. Open `.env` in Notepad and add your API key(s):
   - `AI_API_KEY` for AI responses (Groq-compatible defaults are preconfigured).
   - `TAVILY_API_KEY` for web search (optional).
6. Edit `apps.json` to choose which installed apps can be opened. The shipped list is deliberately conservative.
7. Double-click `start_windows.bat`. It starts the localhost server and opens the UI in Chrome.

Keys stay in `.env` on your computer. Never share `.env`, commit it to Git, or put API keys in the HTML file. API providers may charge for usage; check your account limits and pricing.

## Quick start — Android

Android Chrome can use the same UI only if the Python backend is running on a computer/server that the phone can reach. For a beginner-friendly local setup:
- Start the project on your Windows PC.
- Keep the PC and phone on the same trusted Wi-Fi.
- For phone access, the server must be deliberately configured to listen on the LAN and the Windows firewall must be configured. This starter intentionally binds to `127.0.0.1` only for safety.
- To access it from Android, use a trusted private deployment or intentionally configure a secure LAN setup; do not expose this development server directly to the public internet.

For a standalone Android-only demo, open `standalone.html` in Chrome. The demo has no real AI/API connection and cannot control Android apps or system volume.

## Configuration

`.env.example` options:
- `AI_BASE_URL`: OpenAI-compatible chat completions endpoint. Default points to Groq.
- `AI_MODEL`: model name supported by your provider.
- `AI_API_KEY`: secret API key.
- `TAVILY_API_KEY`: optional web search key.
- `JARVIS_HOST`: defaults to `127.0.0.1`; do not change to `0.0.0.0` unless you understand network exposure and add proper authentication/TLS.
- `JARVIS_PORT`: defaults to `8765`.

## Security model

- Server binds to localhost by default.
- No arbitrary shell or Python execution endpoint.
- Windows apps must be in `apps.json`; commands are fixed by the configuration.
- Device actions require confirmation in the UI and are revalidated by the server.
- Request size is limited; API keys are only read server-side from environment.
- This is a starter project, not a hardened multi-user service. Do not expose it to the internet as-is.


## Phone-first deployment (Chrome + Android app)

The `android-app/` directory is a native Android Studio project with a WebViewAssetLoader-based local UI, Android SpeechRecognizer microphone input, Android TextToSpeech output, and a settings flow for the HTTPS backend URL. It is source code, not a precompiled APK; build it in Android Studio on a computer.

### Deploy backend securely
1. Deploy this project using the included `Dockerfile` / `render.yaml` or another trusted Python host that supports HTTPS.
2. Set `AI_API_KEY` in the host's secret/environment settings. Optionally set `TAVILY_API_KEY`.
3. Set `JARVIS_ACCESS_TOKEN` to a long random secret. Use the exact same token in the web UI's ⚙ SETUP dialog. The backend refuses `/api/*` requests without it when configured.
4. In Chrome, open the web UI deployment and tap ⚙ SETUP to enter backend URL + access token. In Android app, enter backend URL using ⚙ SETUP and token using the web UI's setup dialog.
5. Never put the AI provider key into browser storage, Android source, or HTML. Only the backend environment should hold it.

**Important security note:** the backend token is a client credential and can be extracted by a determined device owner; it protects casual public abuse, not a multi-user production service. For a public app, add user authentication, rate limiting, usage caps, and provider-side spend limits. Do not expose the Windows device-control companion to the public internet.
