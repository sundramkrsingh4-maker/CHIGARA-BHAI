@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run setup_windows.bat first.
  pause
  exit /b 1
)
if not exist .env copy .env.example .env
start "" http://127.0.0.1:8765
.venv\Scripts\python.exe app.py
pause
