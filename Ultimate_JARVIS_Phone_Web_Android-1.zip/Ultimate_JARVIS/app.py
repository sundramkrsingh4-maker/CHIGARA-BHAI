from __future__ import annotations
import json
import os
import platform
import subprocess
import time
from pathlib import Path
from typing import Any

import requests
import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / ".env")
HOST = os.getenv("JARVIS_HOST", "127.0.0.1")
PORT = int(os.getenv("JARVIS_PORT", "8765"))
AI_BASE_URL = os.getenv("AI_BASE_URL", "https://api.groq.com/openai/v1").rstrip("/")
AI_MODEL = os.getenv("AI_MODEL", "llama-3.3-70b-versatile")
AI_API_KEY = os.getenv("AI_API_KEY", "").strip()
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "").strip()
JARVIS_ACCESS_TOKEN = os.getenv("JARVIS_ACCESS_TOKEN", "").strip()
APPS_FILE = BASE / "apps.json"

app = FastAPI(title="JARVIS Local Companion", docs_url=None, redoc_url=None)
# CORS is needed when the Android app loads local assets and calls a remote HTTPS backend.
# Use an access token for any publicly reachable deployment.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False,
                   allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["Authorization", "Content-Type"])
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

@app.middleware("http")
async def protect_api(request: Request, call_next):
    if request.method != "OPTIONS" and request.url.path.startswith("/api/") and JARVIS_ACCESS_TOKEN:
        supplied = request.headers.get("authorization", "")
        if supplied != f"Bearer {JARVIS_ACCESS_TOKEN}":
            return JSONResponse(status_code=401, content={"detail": "Unauthorized. Configure the backend access token in JARVIS setup."})
    return await call_next(request)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=6000)
    history: list[dict[str, str]] = Field(default_factory=list, max_length=16)

class SearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=300)

class ActionRequest(BaseModel):
    action: str = Field(min_length=1, max_length=40)
    target: str | None = Field(default=None, max_length=80)
    confirmed: bool = False

def load_apps() -> dict[str, Any]:
    try:
        value = json.loads(APPS_FILE.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}

@app.get("/")
def index():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/api/status")
def status():
    return {
        "ai_configured": bool(AI_API_KEY),
        "search_configured": bool(TAVILY_API_KEY),
        "access_token_required": bool(JARVIS_ACCESS_TOKEN),
        "device_control_available": platform.system() == "Windows",
        "platform": platform.system(),
        "host": HOST,
    }

@app.post("/api/chat")
def chat(body: ChatRequest):
    if not AI_API_KEY:
        raise HTTPException(503, "AI is not configured. Add AI_API_KEY to .env and restart JARVIS.")
    messages = [{
        "role": "system",
        "content": (
            "You are JARVIS, a helpful voice-first personal assistant. Be clear and concise. "
            "You cannot claim to have performed device actions unless the tool/API result confirms it. "
            "Never ask the user to reveal API keys or passwords. For dangerous, destructive, or "
            "privacy-sensitive actions, recommend explicit user confirmation."
        )
    }]
    for item in body.history[-12:]:
        role = item.get("role")
        content = item.get("content")
        if role in ("user", "assistant") and isinstance(content, str):
            messages.append({"role": role, "content": content[:3000]})
    messages.append({"role": "user", "content": body.message})
    try:
        r = requests.post(
            f"{AI_BASE_URL}/chat/completions",
            headers={"Authorization": f"Bearer {AI_API_KEY}", "Content-Type": "application/json"},
            json={"model": AI_MODEL, "messages": messages, "temperature": 0.5},
            timeout=45,
        )
        if r.status_code >= 400:
            raise HTTPException(502, f"AI provider returned HTTP {r.status_code}. Check provider key, model and quota.")
        data = r.json()
        answer = data["choices"][0]["message"]["content"]
        if not isinstance(answer, str):
            answer = str(answer)
        return {"answer": answer[:12000], "model": AI_MODEL}
    except HTTPException:
        raise
    except requests.RequestException:
        raise HTTPException(502, "Could not reach AI provider. Check internet connection and AI_BASE_URL.")
    except (ValueError, KeyError, IndexError):
        raise HTTPException(502, "AI provider returned an unexpected response.")

@app.post("/api/search")
def search(body: SearchRequest):
    if not TAVILY_API_KEY:
        raise HTTPException(503, "Web search is not configured. Add TAVILY_API_KEY to .env and restart JARVIS.")
    try:
        r = requests.post(
            "https://api.tavily.com/search",
            json={"api_key": TAVILY_API_KEY, "query": body.query, "search_depth": "basic",
                  "max_results": 5, "include_answer": True},
            timeout=25,
        )
        if r.status_code >= 400:
            raise HTTPException(502, f"Search provider returned HTTP {r.status_code}. Check key/quota.")
        data = r.json()
        return {
            "answer": data.get("answer") or "",
            "results": [
                {"title": x.get("title", ""), "url": x.get("url", ""),
                 "content": (x.get("content") or "")[:800]}
                for x in data.get("results", [])[:5]
            ]
        }
    except HTTPException:
        raise
    except requests.RequestException:
        raise HTTPException(502, "Could not reach the search provider.")

@app.post("/api/action")
def action(body: ActionRequest):
    if not body.confirmed:
        raise HTTPException(400, "Action needs confirmation in the interface.")
    if platform.system() != "Windows":
        raise HTTPException(501, "Device controls in this starter are supported only on Windows.")
    if body.action == "open_app":
        apps = load_apps()
        key = (body.target or "").lower().strip()
        item = apps.get(key)
        if not item or not isinstance(item.get("windows_command"), list):
            raise HTTPException(400, "App is not allowlisted. Edit apps.json to add a trusted app.")
        command = item["windows_command"]
        if not command or not all(isinstance(x, str) and x and len(x) < 260 for x in command):
            raise HTTPException(400, "Invalid allowlisted command.")
        try:
            subprocess.Popen(command, shell=False, cwd=str(BASE))
            return {"ok": True, "message": f"Launch request sent for {item.get('label', key)}."}
        except OSError:
            raise HTTPException(500, "Could not launch that app. Check that it is installed.")
    if body.action in ("volume_up", "volume_down", "mute_toggle"):
        try:
            from ctypes import POINTER, cast
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            if body.action == "mute_toggle":
                volume.SetMute(not bool(volume.GetMute()), None)
                return {"ok": True, "message": "Mute state toggled."}
            current = float(volume.GetMasterVolumeLevelScalar())
            new_value = min(1.0, current + 0.05) if body.action == "volume_up" else max(0.0, current - 0.05)
            volume.SetMasterVolumeLevelScalar(new_value, None)
            return {"ok": True, "message": f"System volume set to about {round(new_value * 100)}%."}
        except Exception as exc:
            raise HTTPException(500, "Windows audio control failed. Check pycaw installation and audio device.")
    raise HTTPException(400, "Unsupported action.")

if __name__ == "__main__":
    print(f"JARVIS running locally at http://{HOST}:{PORT}")
    print("Keep this terminal open while using JARVIS.")
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")
