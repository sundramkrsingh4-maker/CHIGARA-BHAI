# Ultimate JARVIS Android app project

This is an Android Studio project (Kotlin + WebViewAssetLoader), not a prebuilt APK. It provides a native Android microphone permission flow, Android SpeechRecognizer input, Android TextToSpeech output, secure HTTPS-only remote backend URL setting, and the shared reactor/radar interface.

## Build APK
1. Install Android Studio on a computer and Android SDK platform 35.
2. Open this `android-app` folder as a project and let Gradle sync.
3. Build > Build APK(s). Android Studio will show the APK path.
4. Install the APK on your phone and grant microphone permission when asked.
5. Tap ⚙ SETUP in JARVIS and enter the deployed HTTPS backend URL and the optional backend access token in the same dialog.

A computer is required for the standard Android Studio build workflow; this source ZIP does not contain a compiled APK. Native speech recognition availability depends on the Android speech service installed on the phone.
