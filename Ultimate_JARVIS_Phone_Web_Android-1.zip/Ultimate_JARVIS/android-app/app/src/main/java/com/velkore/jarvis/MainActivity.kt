package com.velkore.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val micRequest = 442
    private val prefs by lazy { getSharedPreferences("jarvis_settings", MODE_PRIVATE) }
    private var pendingListen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        assetLoader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) = assetLoader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.host == "appassets.androidplatform.net") return false
                if (uri.scheme == "https" || uri.scheme == "http") { startActivity(Intent(Intent.ACTION_VIEW, uri)); return true }
                return true
            }
        }
        web.addJavascriptInterface(AndroidBridge(), "JarvisAndroid")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface fun getBackendUrl(): String = prefs.getString("backend_url", "") ?: ""
        @JavascriptInterface fun speak(text: String) { runOnUiThread { tts?.speak(text.take(4000), TextToSpeech.QUEUE_FLUSH, null, "jarvis-utterance") } }
        @JavascriptInterface fun stopSpeaking() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun startListening() { runOnUiThread { startNativeListening() } }
        @JavascriptInterface fun stopListening() { runOnUiThread { speechRecognizer?.cancel(); js("window.onNativeSpeechResult('',true)") } }
        @JavascriptInterface fun openSettings() { runOnUiThread { showBackendSetup() } }
    }

    private fun showBackendSetup() {
        val input = android.widget.EditText(this).apply { hint = "https://your-backend.example.com"; setSingleLine(true); setText(prefs.getString("backend_url", "")) }
        android.app.AlertDialog.Builder(this).setTitle("JARVIS backend URL").setMessage("Use your deployed HTTPS backend. API provider keys stay on the server.").setView(input)
            .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim().trimEnd('/')
                if (value.isNotEmpty() && !value.startsWith("https://") && !value.startsWith("http://10.0.2.2")) {
                    android.widget.Toast.makeText(this, "Use HTTPS for remote servers", android.widget.Toast.LENGTH_LONG).show()
                } else { prefs.edit().putString("backend_url", value).apply(); web.evaluateJavascript("localStorage.setItem('jarvisBackendUrl', ${org.json.JSONObject.quote(value)}); location.reload()", null) }
            }.show()
    }

    private fun startNativeListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("window.onNativeSpeechError('Speech recognition service is not available on this device')"); return }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { js("window.onNativeSpeechError(${org.json.JSONObject.quote("Speech recognition error code $error")})") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                js("window.onNativeSpeechResult(${org.json.JSONObject.quote(text)},true)")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotEmpty()) js("window.onNativeSpeechResult(${org.json.JSONObject.quote(text)},false)")
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun js(code: String) { runOnUiThread { web.evaluateJavascript(code, null) } }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN") }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && pendingListen) { pendingListen = false; startNativeListening() }
        else if (requestCode == micRequest) js("window.onNativeSpeechError('Microphone permission was denied')")
    }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { speechRecognizer?.destroy(); tts?.stop(); tts?.shutdown(); if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
